<?php 
namespace PayPal\PayPalAPI;
use PayPal\PayPalAPI\DoExpressCheckoutPaymentResponseType; 
/**
 * 
 */
class DoUATPExpressCheckoutPaymentResponseType  extends DoExpressCheckoutPaymentResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PayPal\EBLBaseComponents\UATPDetailsType	 
	 */ 
	public $UATPDetails;


}
