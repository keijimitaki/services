<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package TsunaguMiyagi
 */

get_header();
?>

  <div class="container is-fluid">

	<!-- <main id="primary" class="site-main"> -->
	<main>

    <!-- repeat articles  --> 
    <div class="columns is-desktop is-2">
    
    <?php
    $args = [
    	'post_type' => 'mtssb_article',
    	'posts_per_page' => 9,
    ];
    
    $the_query = new WP_Query($args);
    
    ?>
    get_the_post_thumbnail( array(100,100) );
    
		<?php while($the_query->have_posts()) : $the_query->the_post(); ?>

<?php echo get_the_post_thumbnail( array(100,100) ); ?>

        <div class="card"> 
            <div class="column card-image">
            <figure class="image is-4by3">
              <?php if ( has_post_thumbnail() ) { ?>
                <?php the_post_thumbnail( array(100, 100) );?>
              <?php }else{ ?>
                <img src="デフォルトアイキャッチ画像のURL">
              <?php }?>
              
              <!-- <img src="https://bulma.io/images/placeholders/1280x960.png" alt="Placeholder image"> -->
              
            </figure>
            </div>
            <div class="card-content">
            <div class="media">
                <div class="media-left">
                <figure class="image is-48x48">
                    <img src="https://bulma.io/images/placeholders/96x96.png" alt="Placeholder image">
                </figure>
                </div>
                <div class="media-content">
                <p class="title is-4">John Smith</p>
                <p class="subtitle is-6">@johnsmith</p>
                </div>
            </div>
        
            <div class="content">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Phasellus nec iaculis mauris. <a>@bulmaio</a>.
                <a href="#">#css</a> <a href="#">#responsive</a>
                <br>
                <time datetime="2016-1-1">11:09 PM - 1 Jan 2016</time>
            </div>
            </div>
        </div>
			
		<?php endwhile;  ?>

	</main><!-- #main -->

</div>

<?php
get_sidebar();
get_footer();
